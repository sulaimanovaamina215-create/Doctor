npx @tailwindcss/cli -i ./css/input.css -o ./css/style.css --watch
